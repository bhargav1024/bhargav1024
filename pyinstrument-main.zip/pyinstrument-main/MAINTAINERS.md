# Releasing

```
bin/bump_version.py
git push && git push --tags
```

Deployment to PyPI is performed in GitHub Actions.
