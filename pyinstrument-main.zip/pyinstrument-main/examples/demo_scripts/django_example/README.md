
This is a simple simple test rig to develop pyinstrument's Django middleware
