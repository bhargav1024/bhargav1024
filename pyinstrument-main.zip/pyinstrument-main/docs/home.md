---
html_meta:
    title: Home
hide-toc:
---

# pyinstrument

```{include} ../README.md
---
relative-docs: docs/
relative-images:
start-after: '<!-- MARK intro start -->'
end-before: '<!-- MARK intro end -->'
---
```
