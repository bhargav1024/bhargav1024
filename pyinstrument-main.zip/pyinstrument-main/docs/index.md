pyinstrument
============

```{toctree}
---
maxdepth: 2
caption: "Contents"
---
Home <home.md>
guide.md
how-it-works.md
reference.md
GitHub <https://github.com/joerick/pyinstrument>
```

Indices and tables
------------------

* {ref}`genindex`
* {ref}`search`
