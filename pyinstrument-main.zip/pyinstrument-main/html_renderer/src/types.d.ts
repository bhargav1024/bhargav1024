declare module 'uuid' {
    export function v4(): string;
}
